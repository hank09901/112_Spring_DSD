這是2_always的readme。
以下為file structure。我的testbench會吃 1.dat 2.dat carry.dat golden.dat。
├── 1.dat
├── 2.dat
├── alu_always.v
├── alu_always_tb2.v
├── carry.dat
├── golden.dat
└── readme.txt

Compile method:

vcs alu_always_tb2.v alu_always.v -full64 -R -debug_access+all +v2k