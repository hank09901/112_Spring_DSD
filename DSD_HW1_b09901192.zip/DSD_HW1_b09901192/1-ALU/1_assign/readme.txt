這是1_assign的readme。
以下為file structure。我的testbench會吃 1.dat 2.dat carry.dat golden.dat。
├── 1.dat
├── 2.dat
├── alu_assign.v
├── alu_assign_tb2.v
├── carry.dat
├── golden.dat
└── readme.txt

Compile method:

vcs alu_assign_tb2.v alu_assign.v -full64 -R -debug_access+all +v2k